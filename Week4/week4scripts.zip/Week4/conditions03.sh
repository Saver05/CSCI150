#!/bin/bash

MY_NAME="John"
NAME_1="Bob"
NAME_2="Jane"
NAME_3="Sue"
Name_4="Kate"

if [ ${MY_NAME} == "Ron" ]; then
    echo "Ron is home from vacation"
elif [ ${MY_NAME} != ${NAME_1} ] && [ ${MY_NAME} != ${NAME_2} ] && [ ${MY_NAME} == "John" ]; then
    echo "John is home after some----- Exampl of unnecessary AND logic"
elif [ ${NAME_2} == "Jane" ]  || [ ${NAME_3} == "Sue" ]; then
    echo "Looks like one of the ladies are home"
else
    echo "Who is this stranger?"
fi
