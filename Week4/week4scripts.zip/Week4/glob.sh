#!/bin/bash

if [[ "$ls -a" *.sh ]]; then
fi
