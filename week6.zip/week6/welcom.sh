#!/bin/bash

greeting () {
  echo "Welcome $1"
}

greeting "Everyone"
